var media=(function(){var e=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function t(e){return e}var n=t({matches:[`<all_urls>`],allFrames:!0,runAt:`document_start`,matchAboutBlank:!0,matchOriginAsFallback:!0,main(t){let n=new Set,r=window===window.top,i=null,a=null,o,s=document.hidden,c=!1,l=0,u=async()=>{try{return await e.runtime.sendMessage({type:`GET_POLICY`,url:location.href})}catch{return null}},d=()=>{let e=new Set,t=[document],n=new Set;for(;t.length>0;){let r=t.pop();!r||n.has(r)||(n.add(r),r.querySelectorAll(`audio, video`).forEach(t=>e.add(t)),r.querySelectorAll(`*`).forEach(e=>{e.shadowRoot&&t.push(e.shadowRoot)}))}return[...e]},f=()=>{for(let e of n)(!e.isConnected||e.ended)&&n.delete(e)},p=e=>{if(e.paused||e.ended||e.readyState===0)return!1;n.add(e);try{return e.pause(),!0}catch{return n.delete(e),!1}},m=()=>{f(),c=!0;let e=0;try{for(let t of d())p(t)&&(e+=1)}finally{c=!1}return e},h=async()=>{f();let e=0;for(let t of[...n]){if(!t.paused||t.ended||!t.isConnected){n.delete(t);continue}try{await t.play(),n.delete(t),e+=1}catch{}}return e},g=async t=>{if(!(t<=0))try{await e.runtime.sendMessage({type:`FRAME_PAUSED`,count:t,url:location.href})}catch{}},_=async(t,n)=>{if(!r)return null;try{return await e.runtime.sendMessage({type:`DOCUMENT_VISIBILITY`,hidden:t,url:location.href,transitionId:n})}catch{return null}},v=async()=>{let e=l,t=await u();if(t&&!(!document.hidden||l!==e)){if(t.enabled&&!t.allowed&&t.shouldPause){let e=m();await g(e)}await _(!0,e)}},y=async()=>{if(await _(!1,l),(await u())?.autoResume&&await h(),r&&i){let e=i;i=null,window.setTimeout(()=>C(e),80)}},b=()=>{let e=document.hidden;e!==s&&(s=e,l+=1,e?v():y())},x=()=>{o!==void 0&&window.clearTimeout(o),o=void 0,a?.remove(),a=null},S=e=>e.mediaCount>0&&e.muted?`Paused ${e.mediaCount} media ${e.mediaCount===1?`item`:`items`} and muted fallback audio.`:e.mediaCount>0?`Paused ${e.mediaCount} media ${e.mediaCount===1?`item`:`items`}.`:`Muted this tab’s audio.`,C=t=>{if(!r)return;if(document.hidden){i=t;return}x();let n=document.createElement(`div`);n.id=`payattention-toast-host`,n.style.position=`fixed`,n.style.top=`18px`,n.style.right=`18px`,n.style.zIndex=`2147483647`,n.style.all=`initial`;let s=n.attachShadow({mode:`closed`}),c=document.createElement(`div`);c.setAttribute(`role`,`status`),c.setAttribute(`aria-live`,`polite`),c.innerHTML=`
        <style>
          :host { all: initial; }
          .toast {
            width: min(360px, calc(100vw - 36px));
            box-sizing: border-box;
            border: 1px solid rgba(255,255,255,.16);
            border-radius: 14px;
            background: rgba(15, 23, 42, .96);
            color: #f8fafc;
            box-shadow: 0 18px 50px rgba(2, 6, 23, .32);
            font-family: ui-sans-serif, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            padding: 14px 14px 12px;
            animation: pa-enter 160ms ease-out;
          }
          @keyframes pa-enter {
            from { opacity: 0; transform: translateY(-8px) scale(.98); }
            to { opacity: 1; transform: translateY(0) scale(1); }
          }
          .top { display: flex; align-items: start; gap: 10px; }
          .mark {
            display: grid;
            place-items: center;
            flex: 0 0 30px;
            width: 30px;
            height: 30px;
            border-radius: 9px;
            background: #f59e0b;
            color: #111827;
            font-weight: 900;
            letter-spacing: -1px;
          }
          .copy { flex: 1; min-width: 0; }
          .title { margin: 0; font-size: 13px; line-height: 1.35; font-weight: 750; }
          .reason { margin: 4px 0 0; color: #cbd5e1; font-size: 12px; line-height: 1.4; }
          .close {
            appearance: none;
            border: 0;
            background: transparent;
            color: #94a3b8;
            cursor: pointer;
            font-size: 18px;
            line-height: 1;
            padding: 0 2px;
          }
          .actions { display: flex; justify-content: flex-end; gap: 8px; margin-top: 11px; }
          .resume {
            appearance: none;
            border: 0;
            border-radius: 9px;
            background: #f8fafc;
            color: #0f172a;
            cursor: pointer;
            font-size: 12px;
            font-weight: 750;
            padding: 8px 11px;
          }
          .resume:hover { background: #e2e8f0; }
        </style>
        <div class="toast">
          <div class="top">
            <div class="mark">PA</div>
            <div class="copy">
              <p class="title"></p>
              <p class="reason"></p>
            </div>
            <button class="close" type="button" aria-label="Dismiss">×</button>
          </div>
          <div class="actions"></div>
        </div>
      `;let l=c.querySelector(`.title`),u=c.querySelector(`.reason`),d=c.querySelector(`.close`),f=c.querySelector(`.actions`);if(!(!l||!u||!d||!f)){if(l.textContent=S(t),u.textContent=t.autoResume?`PayAttention resumed tracked media when you returned.`:t.showReason?`Reason: ${t.reason}`:``,u.hidden=!u.textContent,d.addEventListener(`click`,x),t.showUndo&&!t.autoResume){let t=document.createElement(`button`);t.className=`resume`,t.type=`button`,t.textContent=`Resume`,t.addEventListener(`click`,()=>{e.runtime.sendMessage({type:`RESUME_TAB_MEDIA`}),x()}),f.append(t)}else f.remove();s.append(c),(document.documentElement??document.body)?.append(n),a=n,o=window.setTimeout(x,Math.max(2e3,t.durationMs))}};document.addEventListener(`visibilitychange`,b,!0),window.addEventListener(`pagehide`,()=>{document.hidden||v()},!0),document.addEventListener(`play`,e=>{let t=e.target;if(t instanceof HTMLMediaElement){if(!document.hidden){c||n.delete(t);return}u().then(async e=>{!e?.enabled||e.allowed||!e.shouldPause||p(t)&&await g(1)})}},!0),e.runtime.onMessage.addListener((e,t,n)=>{let i=e;return i.type===`SHOW_TOAST`?(r&&C(i.payload),n({ok:!0}),!1):i.type===`RESUME_MEDIA`?(h().then(e=>n({ok:!0,count:e})),!0):!1}),t.onInvalidated(()=>{document.removeEventListener(`visibilitychange`,b,!0),x()}),document.hidden&&v()}}),r={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},i=class e extends Event{static EVENT_NAME=a(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function a(t){return`${e?.runtime?.id}:media:${t}`}var o=typeof globalThis.navigation?.addEventListener==`function`;function s(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),o?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new i(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new i(e,t)),t=e)},1e3))}}}var c=class t{static SCRIPT_STARTED_MESSAGE_TYPE=a(`wxt:content-script-started`);id;abortController;locationWatcher=s(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return e.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?a(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),r.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(t.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:t.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let e=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(t.SCRIPT_STARTED_MESSAGE_TYPE,e),this.onInvalidated(()=>document.removeEventListener(t.SCRIPT_STARTED_MESSAGE_TYPE,e))}},l={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=n;return await e(new c(`media`,t))}catch(e){throw l.error(`The content script "media" crashed on startup!`,e),e}})()})();
media;